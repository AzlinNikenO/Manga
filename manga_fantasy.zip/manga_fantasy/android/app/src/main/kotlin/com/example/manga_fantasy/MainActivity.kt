package com.example.manga_fantasy

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
