class Manga {
  final int? id;
  final String title;
  final String japaneseTitle;
  final String author;
  final String artist;
  final String synopsis;
  final String status;
  final int year;
  final double rating;
  final List<String> genres;
  final String? coverImagePath;
  final List<Chapter> chapters;
  final DateTime createdAt;
  final DateTime updatedAt;

  Manga({
    this.id,
    required this.title,
    this.japaneseTitle = '',
    required this.author,
    this.artist = '',
    required this.synopsis,
    this.status = 'Ongoing',
    required this.year,
    this.rating = 0.0,
    required this.genres,
    this.coverImagePath,
    this.chapters = const [],
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  // Helper getter untuk genre string (untuk API)
  String get genreString => genres.join(',');

  // Helper getter untuk genre list
  List<String> get genreList => genres;

  factory Manga.fromJson(Map<String, dynamic> json) {
    // Handle id yang bisa berupa String atau int
    int? parsedId;
    if (json['id'] != null) {
      if (json['id'] is int) {
        parsedId = json['id'];
      } else if (json['id'] is String) {
        parsedId = int.tryParse(json['id']);
      }
    }

    return Manga(
      id: parsedId,
      title: json['title'] as String,
      japaneseTitle: json['japanese_title'] as String? ?? '',
      author: json['author'] as String,
      artist: json['artist'] as String? ?? '',
      synopsis: json['synopsis'] as String,
      status: json['status'] as String? ?? 'Ongoing',
      year: json['year'] as int,
      rating: (json['rating'] as num?)?.toDouble() ?? 0.0,
      genres: (json['genre'] as String?)?.split(',').map((g) => g.trim()).toList() ?? [],
      coverImagePath: json['cover_image'] as String?,
      chapters: (json['chapters'] as List?)?.map((c) => Chapter.fromJson(c)).toList() ?? [],
      createdAt: json['created_at'] != null ? DateTime.parse(json['created_at']) : DateTime.now(),
      updatedAt: json['updated_at'] != null ? DateTime.parse(json['updated_at']) : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'title': title,
      'japanese_title': japaneseTitle,
      'author': author,
      'artist': artist,
      'synopsis': synopsis,
      'status': status,
      'year': year,
      'rating': rating,
      'genre': genreString,
      'cover_image': coverImagePath,
    };
  }
}

class Chapter {
  final String id;
  final String mangaId;
  final String chapterNumber;
  final String title;
  final List<String> pageImagePaths;
  final int pageCount;
  final DateTime releaseDate;

  Chapter({
    required this.id,
    required this.mangaId,
    required this.chapterNumber,
    this.title = '',
    this.pageImagePaths = const [],
    this.pageCount = 0,
    DateTime? releaseDate,
  }) : releaseDate = releaseDate ?? DateTime.now();

  factory Chapter.fromJson(Map<String, dynamic> json) {
    return Chapter(
      id: json['id'] as String,
      mangaId: json['mangaId'] as String,
      chapterNumber: json['chapterNumber'] as String,
      title: json['title'] as String? ?? '',
      pageImagePaths: (json['pageImagePaths'] as List?)?.cast<String>() ?? [],
      pageCount: json['pageCount'] as int? ?? 0,
      releaseDate: json['releaseDate'] != null ? DateTime.parse(json['releaseDate']) : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'mangaId': mangaId,
      'chapterNumber': chapterNumber,
      'title': title,
      'pageImagePaths': pageImagePaths,
      'pageCount': pageCount,
      'releaseDate': releaseDate.toIso8601String(),
    };
  }
}

enum ReadingMode {
  vertical,
  horizontal,
}

extension ReadingModeExtension on ReadingMode {
  String get label {
    switch (this) {
      case ReadingMode.vertical:
        return 'Gulir Vertikal';
      case ReadingMode.horizontal:
        return 'Geser Horizontal';
    }
  }
}