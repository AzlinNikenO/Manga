import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/manga_model.dart';
import '../providers/reading_provider.dart';
import '../providers/manga_provider.dart';
import 'reading_screen.dart';
import 'add_edit_screen.dart';

class MangaDetailScreen extends StatefulWidget {
  final Manga manga;

  const MangaDetailScreen({super.key, required this.manga});

  @override
  State<MangaDetailScreen> createState() => _MangaDetailScreenState();
}

class _MangaDetailScreenState extends State<MangaDetailScreen> {
  late Manga _manga;

  @override
  void initState() {
    super.initState();
    _manga = widget.manga;
  }

  void _editManga() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddEditScreen(manga: _manga),
      ),
    );
    
    if (result == true && mounted) {
      final mangaProvider = Provider.of<MangaProvider>(context, listen: false);
      await mangaProvider.loadMangas();
      
      // Refresh with updated manga
      final updatedManga = mangaProvider.getMangaById(widget.manga.id!); // id harus int
      if (updatedManga != null) {
        setState(() {
          _manga = updatedManga;
        });
      }
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Manga berhasil diupdate')),
      );
    }
  }

  void _deleteManga() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Manga'),
        content: Text('Apakah Anda yakin ingin menghapus "${_manga.title}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              
              final mangaProvider = Provider.of<MangaProvider>(context, listen: false);
              final success = await mangaProvider.deleteManga(widget.manga.id!); // id harus int
              
              if (mounted) {
                if (success) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Manga berhasil dihapus')),
                  );
                  Navigator.pop(context); // Back to home
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(mangaProvider.errorMessage ?? 'Gagal menghapus manga')),
                  );
                }
              }
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final readingProvider = Provider.of<ReadingProvider>(context);
    final lastReadChapterId = readingProvider.getLastReadChapter(_manga.id.toString());


    return Scaffold(
      appBar: AppBar(
        title: Text(
          _manga.title,
          style: const TextStyle(fontSize: 18),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: _editManga,
          ),
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: _deleteManga,
          ),
        ],
      ),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: _buildHeader(context),
          ),
          SliverToBoxAdapter(
            child: _buildSynopsis(context),
          ),
          SliverToBoxAdapter(
            child: _buildChaptersHeader(context),
          ),
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                final chapter = _manga.chapters[index];
                final isLastRead = lastReadChapterId == chapter.id;
                return _buildChapterTile(context, chapter, isLastRead);
              },
              childCount: _manga.chapters.length,
            ),
          ),
          if (_manga.chapters.isEmpty)
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Center(
                  child: Text('Belum ada chapter'),
                ),
              ),
            ),
        ],
      ),
      floatingActionButton: _manga.chapters.isNotEmpty
          ? FloatingActionButton.extended(
              onPressed: () {
                final firstChapter = _manga.chapters.first;
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ReadingScreen(
                      manga: _manga,
                      chapter: firstChapter,
                    ),
                  ),
                );
              },
              icon: const Icon(Icons.play_arrow),
              label: const Text('Start Reading'),
            )
          : null,
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 120,
            height: 160,
            decoration: BoxDecoration(
              color: Colors.grey.shade300,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Center(
              child: Icon(Icons.menu_book, size: 48),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _manga.title,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                if (_manga.japaneseTitle.isNotEmpty)
                  Text(
                    _manga.japaneseTitle,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey.shade600,
                    ),
                  ),
                const SizedBox(height: 8),
                Text(
                  'By: ${_manga.author}',
                  style: const TextStyle(fontSize: 12),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: _manga.genreList.map((genre) {
                    return Chip(
                      label: Text(genre),
                      labelStyle: const TextStyle(fontSize: 11),
                      padding: EdgeInsets.zero,
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    );
                  }).toList(),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Icon(Icons.star, size: 16, color: Colors.amber),
                    const SizedBox(width: 4),
                    Text(_manga.rating.toString()),
                    const SizedBox(width: 16),
                    const Icon(Icons.calendar_today, size: 14),
                    const SizedBox(width: 4),
                    Text(_manga.year.toString()),
                    const SizedBox(width: 16),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: _manga.status == 'Ongoing'
                            ? Colors.green.shade100
                            : Colors.blue.shade100,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        _manga.status,
                        style: TextStyle(
                          fontSize: 11,
                          color: _manga.status == 'Ongoing'
                              ? Colors.green.shade800
                              : Colors.blue.shade800,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSynopsis(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Synopsis',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _manga.synopsis,
            style: TextStyle(
              fontSize: 14,
              height: 1.5,
              color: Colors.grey.shade700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChaptersHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Chapters (${_manga.chapters.length})',
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChapterTile(BuildContext context, Chapter chapter, bool isLastRead) {
    return ListTile(
      leading: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primaryContainer,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Center(
          child: Text(
            chapter.chapterNumber,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Theme.of(context).colorScheme.onPrimaryContainer,
            ),
          ),
        ),
      ),
      title: Text(
        'Chapter ${chapter.chapterNumber}${chapter.title.isNotEmpty ? ': ${chapter.title}' : ''}',
        style: TextStyle(
          fontWeight: isLastRead ? FontWeight.bold : FontWeight.normal,
        ),
      ),
      trailing: isLastRead
          ? Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.green.shade100,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                'Last Read',
                style: TextStyle(
                  fontSize: 11,
                  color: Colors.green.shade800,
                ),
              ),
            )
          : null,
      onTap: () {
        final readingProvider = Provider.of<ReadingProvider>(context, listen: false);
        readingProvider.saveReadingProgress(_manga.id.toString(), chapter.id);
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ReadingScreen(
              manga: _manga,
              chapter: chapter,
            ),
          ),
        );
      },
    );
  }
}