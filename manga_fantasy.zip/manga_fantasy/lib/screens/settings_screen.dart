import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../providers/reading_provider.dart';
import '../models/manga_model.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final readingProvider = Provider.of<ReadingProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        centerTitle: true,
      ),
      body: ListView(
        children: [
          const SizedBox(height: 16),

          _buildSectionHeader('Appearance'),

          SwitchListTile(
            title: const Text('Dark Mode'),
            subtitle: const Text('Switch between light and dark theme'),
            secondary: Icon(
              themeProvider.isDarkMode ? Icons.dark_mode : Icons.light_mode,
              color: themeProvider.isDarkMode ? Colors.amber : Colors.blue,
            ),
            value: themeProvider.isDarkMode,
            onChanged: (value) {
              themeProvider.toggleTheme();
            },
          ),

          _buildSectionHeader('Typography'),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Font Size'),
                    Text(
                      '${themeProvider.fontSize.toStringAsFixed(0)}px',
                      style: TextStyle(
                        color: Theme.of(context).primaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Slider(
                  value: themeProvider.fontSize,
                  min: 10,
                  max: 24,
                  divisions: 14,
                  label: themeProvider.fontSize.round().toString(),
                  onChanged: (value) {
                    themeProvider.setFontSize(value);
                  },
                ),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Aa', style: TextStyle(fontSize: 10)),
                    Text('Aa', style: TextStyle(fontSize: 14)),
                    Text('Aa', style: TextStyle(fontSize: 18)),
                    Text('Aa', style: TextStyle(fontSize: 22)),
                    Text('Aa', style: TextStyle(fontSize: 24)),
                  ],
                ),
              ],
            ),
          ),

          _buildSectionHeader('Reading Preferences'),

          ListTile(
            leading: const Icon(Icons.swipe_vertical),
            title: const Text('Default Reading Mode'),
            subtitle: Text(readingProvider.currentReadingMode.label),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              _showReadingModeDialog(context);
            },
          ),

          const Divider(),

          _buildSectionHeader('About'),

          const ListTile(
            leading: Icon(Icons.info),
            title: Text('Version'),
            subtitle: Text('1.0.0'),
          ),

          const ListTile(
            leading: Icon(Icons.book),
            title: Text('Manga Fantasy Reader'),
            subtitle: Text('A beautiful manga reading app'),
          ),

          const SizedBox(height: 32),

          Center(
            child: Text(
              '© 2024 Manga Fantasy Reader',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey.shade600,
              ),
            ),
          ),

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: Colors.grey.shade700,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  void _showReadingModeDialog(BuildContext context) {
    final readingProvider = Provider.of<ReadingProvider>(context, listen: false);
    ReadingMode tempMode = readingProvider.currentReadingMode;

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateBottom) {
            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'Reading Settings',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 16),
                    RadioListTile<ReadingMode>(
                      title: const Text('Vertical Scroll'),
                      subtitle: const Text('Scroll continuously like Webtoon'),
                      value: ReadingMode.vertical,
                      groupValue: tempMode,
                      onChanged: (value) {
                        if (value != null) {
                          setStateBottom(() {
                            tempMode = value;
                          });
                        }
                      },
                    ),
                    RadioListTile<ReadingMode>(
                      title: const Text('Horizontal Swipe'),
                      subtitle: const Text('Page by page like Japanese manga'),
                      value: ReadingMode.horizontal,
                      groupValue: tempMode,
                      onChanged: (value) {
                        if (value != null) {
                          setStateBottom(() {
                            tempMode = value;
                          });
                        }
                      },
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () {
                        readingProvider.setReadingMode(tempMode);
                        Navigator.pop(context);
                      },
                      child: const Text('Apply'),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}