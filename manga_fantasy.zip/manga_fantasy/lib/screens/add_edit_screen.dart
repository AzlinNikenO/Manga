import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/manga_model.dart';
import '../providers/manga_provider.dart';
import '../utils/validators.dart';

class AddEditScreen extends StatefulWidget {
  final Manga? manga;

  const AddEditScreen({super.key, this.manga});

  @override
  State<AddEditScreen> createState() => _AddEditScreenState();
}

class _AddEditScreenState extends State<AddEditScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _titleController;
  late TextEditingController _japaneseTitleController;
  late TextEditingController _authorController;
  late TextEditingController _artistController;
  late TextEditingController _synopsisController;
  late TextEditingController _yearController;
  late TextEditingController _ratingController;
  late String _selectedStatus;
  late List<String> _selectedGenres;

  final List<String> _availableGenres = [
    'Fantasy', 'Action', 'Adventure', 'Romance', 'Comedy',
    'Drama', 'Horror', 'Mystery', 'Sci-Fi', 'Slice of Life',
    'Dark Fantasy', 'Magic', 'Isekai', 'Historical', 'Supernatural'
  ];

  bool get isEditing => widget.manga != null;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.manga?.title ?? '');
    _japaneseTitleController = TextEditingController(text: widget.manga?.japaneseTitle ?? '');
    _authorController = TextEditingController(text: widget.manga?.author ?? '');
    _artistController = TextEditingController(text: widget.manga?.artist ?? '');
    _synopsisController = TextEditingController(text: widget.manga?.synopsis ?? '');
    _yearController = TextEditingController(text: widget.manga?.year.toString() ?? DateTime.now().year.toString());
    _ratingController = TextEditingController(text: widget.manga?.rating.toString() ?? '0');
    _selectedStatus = widget.manga?.status ?? 'Ongoing';
    _selectedGenres = widget.manga?.genres.toList() ?? [];
  }

  @override
  void dispose() {
    _titleController.dispose();
    _japaneseTitleController.dispose();
    _authorController.dispose();
    _artistController.dispose();
    _synopsisController.dispose();
    _yearController.dispose();
    _ratingController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    
    if (_selectedGenres.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pilih minimal 1 genre')),
      );
      return;
    }

    final mangaProvider = Provider.of<MangaProvider>(context, listen: false);

    final mangaData = Manga(
      id: widget.manga?.id,
      title: _titleController.text.trim(),
      japaneseTitle: _japaneseTitleController.text.trim(),
      author: _authorController.text.trim(),
      artist: _artistController.text.trim(),
      synopsis: _synopsisController.text.trim(),
      status: _selectedStatus,
      year: int.parse(_yearController.text),
      rating: double.parse(_ratingController.text),
      genres: _selectedGenres,
    );

    bool success;
    if (isEditing) {
      success = await mangaProvider.updateManga(mangaData);
    } else {
      success = await mangaProvider.addManga(mangaData);
    }

    if (mounted) {
      if (success) {
        Navigator.pop(context, true);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(mangaProvider.errorMessage ?? 'Gagal menyimpan')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? 'Edit Manga' : 'Tambah Manga'),
        centerTitle: true,
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Title
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(
                  labelText: 'Judul Manga *',
                  border: OutlineInputBorder(),
                ),
                validator: Validators.validateTitle,
              ),
              const SizedBox(height: 16),

              // Japanese Title
              TextFormField(
                controller: _japaneseTitleController,
                decoration: const InputDecoration(
                  labelText: 'Judul Jepang (Optional)',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),

              // Author
              TextFormField(
                controller: _authorController,
                decoration: const InputDecoration(
                  labelText: 'Author *',
                  border: OutlineInputBorder(),
                ),
                validator: Validators.validateAuthor,
              ),
              const SizedBox(height: 16),

              // Artist
              TextFormField(
                controller: _artistController,
                decoration: const InputDecoration(
                  labelText: 'Artist (Optional)',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),

              // Synopsis
              TextFormField(
                controller: _synopsisController,
                decoration: const InputDecoration(
                  labelText: 'Sinopsis *',
                  border: OutlineInputBorder(),
                ),
                maxLines: 5,
                validator: Validators.validateSynopsis,
              ),
              const SizedBox(height: 16),

              // Year and Rating Row
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _yearController,
                      decoration: const InputDecoration(
                        labelText: 'Tahun *',
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.number,
                      validator: Validators.validateYear,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: TextFormField(
                      controller: _ratingController,
                      decoration: const InputDecoration(
                        labelText: 'Rating (0-10) *',
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.number,
                      validator: Validators.validateRating,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // Status
              DropdownButtonFormField<String>(
                value: _selectedStatus,
                decoration: const InputDecoration(
                  labelText: 'Status',
                  border: OutlineInputBorder(),
                ),
                items: const [
                  DropdownMenuItem(value: 'Ongoing', child: Text('Ongoing')),
                  DropdownMenuItem(value: 'Complete', child: Text('Complete')),
                ],
                onChanged: (value) {
                  setState(() {
                    _selectedStatus = value!;
                  });
                },
              ),
              const SizedBox(height: 16),

              // Genres
              const Text('Genre *', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _availableGenres.map((genre) {
                  final isSelected = _selectedGenres.contains(genre);
                  return FilterChip(
                    label: Text(genre),
                    selected: isSelected,
                    onSelected: (selected) {
                      setState(() {
                        if (selected) {
                          _selectedGenres.add(genre);
                        } else {
                          _selectedGenres.remove(genre);
                        }
                      });
                    },
                  );
                }).toList(),
              ),
              if (_selectedGenres.isEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    'Pilih minimal 1 genre',
                    style: TextStyle(color: Colors.red.shade700, fontSize: 12),
                  ),
                ),
              const SizedBox(height: 32),

              // Save Button
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _save,
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(isEditing ? 'Update Manga' : 'Simpan Manga'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}