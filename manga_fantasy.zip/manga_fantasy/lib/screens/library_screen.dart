import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/manga_model.dart';  // PASTIKAN IMPORT INI ADA
import '../providers/manga_provider.dart';
import '../providers/reading_provider.dart';
import '../widgets/manga_card.dart';
import 'manga_detail_screen.dart';
import 'add_edit_screen.dart';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  String _filter = 'All';

  @override
  Widget build(BuildContext context) {
    final mangaProvider = Provider.of<MangaProvider>(context);
    final readingProvider = Provider.of<ReadingProvider>(context);
    
    List<Manga> filteredMangas = mangaProvider.mangas;

if (_filter != 'All') {
  filteredMangas = filteredMangas.where((m) => m.status == _filter).toList();
}

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Library'),
        centerTitle: true,
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.filter_list),
            onSelected: (value) {
              setState(() {
                _filter = value;
              });
            },
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'All', child: Text('All')),
              const PopupMenuItem(value: 'Ongoing', child: Text('Ongoing')),
              const PopupMenuItem(value: 'Complete', child: Text('Complete')),
            ],
          ),
        ],
      ),
      body: mangaProvider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : filteredMangas.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.library_books, size: 64, color: Colors.grey.shade400),
                      const SizedBox(height: 16),
                      Text(
                        'No manga in library',
                        style: TextStyle(fontSize: 18, color: Colors.grey.shade600),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Add manga by tapping the + button',
                        style: TextStyle(fontSize: 14, color: Colors.grey.shade500),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: () => mangaProvider.loadMangas(),
                  child: GridView.builder(
                    padding: const EdgeInsets.all(12),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.68,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                    ),
                    itemCount: filteredMangas.length,
                    itemBuilder: (context, index) {
                      final manga = filteredMangas[index];
                      final lastReadChapterId = readingProvider.getLastReadChapter(manga.id.toString());
                      
                      return Stack(
                        children: [
                          MangaCard(
                            manga: manga,
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => MangaDetailScreen(manga: manga),
                                ),
                              );
                            },
                          ),
                          if (lastReadChapterId != null)
                            Positioned(
                              bottom: 8,
                              left: 8,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.green.shade800,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  'Continue',
                                  style: const TextStyle(color: Colors.white, fontSize: 10),
                                ),
                              ),
                            ),
                        ],
                      );
                    },
                  ),
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const AddEditScreen(),
            ),
          ).then((result) {
            if (result == true) {
              mangaProvider.loadMangas();
            }
          });
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}