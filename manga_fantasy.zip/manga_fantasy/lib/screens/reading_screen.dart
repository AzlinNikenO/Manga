import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/manga_model.dart';
import '../providers/reading_provider.dart';
import '../providers/theme_provider.dart';
import '../widgets/vertical_reader.dart';
import '../widgets/horizontal_reader.dart';

class ReadingScreen extends StatefulWidget {
  final Manga manga;
  final Chapter chapter;

  const ReadingScreen({
    super.key,
    required this.manga,
    required this.chapter,
  });

  @override
  State<ReadingScreen> createState() => _ReadingScreenState();
}

class _ReadingScreenState extends State<ReadingScreen> {
  late ReadingMode _readingMode;
  bool _showControls = true;

  @override
  void initState() {
    super.initState();
    final readingProvider = Provider.of<ReadingProvider>(context, listen: false);
    _readingMode = readingProvider.currentReadingMode;
    _saveProgress();
  }

  void _saveProgress() {
    final readingProvider = Provider.of<ReadingProvider>(context, listen: false);
    readingProvider.saveReadingProgress(widget.manga.id.toString(), widget.chapter.id);
  }

  void _toggleControls() {
    setState(() {
      _showControls = !_showControls;
    });
  }

  void _changeReadingMode() {
    final readingProvider = Provider.of<ReadingProvider>(context, listen: false);
    setState(() {
      if (_readingMode == ReadingMode.vertical) {
        _readingMode = ReadingMode.horizontal;
      } else {
        _readingMode = ReadingMode.vertical;
      }
      readingProvider.setReadingMode(_readingMode);
    });
  }

  @override
  Widget build(BuildContext context) {
    // PERBAIKAN: Ambil themeProvider di sini
    final themeProvider = Provider.of<ThemeProvider>(context);
    final readingProvider = Provider.of<ReadingProvider>(context);
    
    final lastPage = readingProvider.getLastReadPage(widget.manga.id.toString()) ?? 0;

    return Scaffold(
      backgroundColor: themeProvider.isDarkMode ? Colors.black : Colors.white,
      body: GestureDetector(
        onTap: _toggleControls,
        child: Stack(
          children: [
            if (_readingMode == ReadingMode.vertical)
              VerticalReader(
                chapter: widget.chapter,
                initialPage: lastPage,
                mangaId: widget.manga.id.toString(),
              )
            else
              HorizontalReader(
                chapter: widget.chapter,
                initialPage: lastPage,
                mangaId: widget.manga.id.toString(),
              ),
            
            AnimatedOpacity(
              opacity: _showControls ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 300),
              child: _buildControlsOverlay(context, themeProvider), // PERBAIKAN: Kirim themeProvider
            ),
          ],
        ),
      ),
    );
  }

  // PERBAIKAN: Tambahkan parameter themeProvider
  Widget _buildControlsOverlay(BuildContext context, ThemeProvider themeProvider) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Colors.black.withValues(alpha: 0.7),
            Colors.transparent,
            Colors.transparent,
            Colors.black.withValues(alpha: 0.7),
          ],
          stops: const [0.0, 0.15, 0.85, 1.0],
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.manga.title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          'Chapter ${widget.chapter.chapterNumber}${widget.chapter.title.isNotEmpty ? ': ${widget.chapter.title}' : ''}',
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: Icon(
                      _readingMode == ReadingMode.vertical 
                          ? Icons.swipe 
                          : Icons.swipe_vertical,
                      color: Colors.white,
                    ),
                    onPressed: _changeReadingMode,
                    tooltip: _readingMode == ReadingMode.vertical
                        ? 'Switch to Horizontal'
                        : 'Switch to Vertical',
                  ),
                  IconButton(
                    icon: Icon(
                      themeProvider.isDarkMode ? Icons.light_mode : Icons.dark_mode,
                      color: Colors.white,
                    ),
                    onPressed: () {
                      themeProvider.toggleTheme();
                    },
                  ),
                ],
              ),
            ),
            
            const Spacer(),
            
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildChapterButton(
                    icon: Icons.skip_previous,
                    label: 'Prev',
                    onTap: _previousChapter,
                  ),
                  _buildChapterButton(
                    icon: Icons.list,
                    label: 'Chapters',
                    onTap: _showChapterList,
                  ),
                  _buildChapterButton(
                    icon: Icons.skip_next,
                    label: 'Next',
                    onTap: _nextChapter,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChapterButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(30),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.7),
          borderRadius: BorderRadius.circular(30),
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.white, size: 20),
            const SizedBox(width: 4),
            Text(
              label,
              style: const TextStyle(color: Colors.white, fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }

  void _previousChapter() {
    final currentIndex = widget.manga.chapters.indexWhere(
      (c) => c.id == widget.chapter.id,
    );
    
    if (currentIndex > 0) {
      final prevChapter = widget.manga.chapters[currentIndex - 1];
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => ReadingScreen(
            manga: widget.manga,
            chapter: prevChapter,
          ),
        ),
      );
    } else {
      _showSnackBar('Already at first chapter');
    }
  }

  void _nextChapter() {
    final currentIndex = widget.manga.chapters.indexWhere(
      (c) => c.id == widget.chapter.id,
    );
    
    if (currentIndex < widget.manga.chapters.length - 1) {
      final nextChapter = widget.manga.chapters[currentIndex + 1];
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => ReadingScreen(
            manga: widget.manga,
            chapter: nextChapter,
          ),
        ),
      );
    } else {
      _showSnackBar('This is the latest chapter');
    }
  }

  void _showChapterList() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'Chapters',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: widget.manga.chapters.length,
                  itemBuilder: (context, index) {
                    final chapter = widget.manga.chapters[index];
                    final isCurrent = chapter.id == widget.chapter.id;
                    
                    return ListTile(
                      leading: Text(chapter.chapterNumber),
                      title: Text(
                        'Chapter ${chapter.chapterNumber}',
                        style: TextStyle(
                          fontWeight: isCurrent ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                      trailing: isCurrent
                          ? const Icon(Icons.check, color: Colors.green)
                          : null,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ReadingScreen(
                              manga: widget.manga,
                              chapter: chapter,
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 1),
      ),
    );
  }
}