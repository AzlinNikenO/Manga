import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart'; 
import '../models/manga_model.dart';
import '../providers/reading_provider.dart';

class HorizontalReader extends StatefulWidget {
  final Chapter chapter;
  final int initialPage;
  final String mangaId;

  const HorizontalReader({
    super.key,
    required this.chapter,
    required this.initialPage,
    required this.mangaId,
  });

  @override
  State<HorizontalReader> createState() => _HorizontalReaderState();
}

class _HorizontalReaderState extends State<HorizontalReader> {
  late PageController _pageController;
  int _currentPage = 0;

  @override
  void initState() {
    super.initState();
    _currentPage = widget.initialPage;
    _pageController = PageController(initialPage: widget.initialPage);
    _saveProgressOnPageChange();
  }

  void _saveProgressOnPageChange() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _pageController.addListener(() {
        final page = _pageController.page?.round() ?? 0;
        if (page != _currentPage) {
          setState(() {
            _currentPage = page;
          });
          final readingProvider = Provider.of<ReadingProvider>(context, listen: false);
          readingProvider.saveLastReadPage(widget.mangaId, page);
        }
      });
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final isDarkMode = themeProvider.isDarkMode;
    
    // Generate dummy pages (in real app, these would be actual images)
    final pageCount = widget.chapter.pageCount > 0 ? widget.chapter.pageCount : 30;

    return Column(
      children: [
        // Chapter title header
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          color: isDarkMode ? Colors.grey.shade900 : Colors.grey.shade100,
          child: Text(
            'Chapter ${widget.chapter.chapterNumber}${widget.chapter.title.isNotEmpty ? ': ${widget.chapter.title}' : ''}',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: isDarkMode ? Colors.white70 : Colors.black54,
            ),
            textAlign: TextAlign.center,
          ),
        ),
        
        // Page viewer
        Expanded(
          child: PageView.builder(
            controller: _pageController,
            physics: const BouncingScrollPhysics(),
            itemCount: pageCount + 1, // +1 for end indicator
            itemBuilder: (context, index) {
              if (index == pageCount) {
                return _buildEndIndicator(context, isDarkMode);
              }
              return _buildPage(context, index, isDarkMode, index + 1, pageCount);
            },
          ),
        ),
        
        // Page indicator
        Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          color: isDarkMode ? Colors.grey.shade900 : Colors.grey.shade100,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Page ${_currentPage + 1} of $pageCount',
                style: TextStyle(
                  fontSize: 12,
                  color: isDarkMode ? Colors.white54 : Colors.black54,
                ),
              ),
              const SizedBox(width: 16),
              Container(
                width: 60,
                height: 2,
                decoration: BoxDecoration(
                  color: isDarkMode ? Colors.grey.shade700 : Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(1),
                ),
                child: FractionallySizedBox(
                  widthFactor: (_currentPage + 1) / pageCount,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Theme.of(context).primaryColor,
                      borderRadius: BorderRadius.circular(1),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPage(BuildContext context, int index, bool isDarkMode, int pageNum, int totalPages) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: isDarkMode ? Colors.grey.shade800 : Colors.grey.shade200,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.image,
            size: 64,
            color: isDarkMode ? Colors.grey.shade600 : Colors.grey.shade400,
          ),
          const SizedBox(height: 16),
          Text(
            'Page $pageNum',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w500,
              color: isDarkMode ? Colors.white70 : Colors.black54,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Swipe horizontally to continue',
            style: TextStyle(
              fontSize: 14,
              color: isDarkMode ? Colors.grey.shade500 : Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEndIndicator(BuildContext context, bool isDarkMode) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: isDarkMode ? Colors.grey.shade800 : Colors.grey.shade200,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.check_circle, size: 64, color: Colors.green),
          const SizedBox(height: 16),
          Text(
            'End of Chapter ${widget.chapter.chapterNumber}',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w500,
              color: isDarkMode ? Colors.white70 : Colors.black54,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'You\'ve completed this chapter',
            style: TextStyle(
              fontSize: 14,
              color: isDarkMode ? Colors.grey.shade500 : Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }
}