import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart'; 
import '../models/manga_model.dart';
import '../providers/reading_provider.dart';

class VerticalReader extends StatefulWidget {
  final Chapter chapter;
  final int initialPage;
  final String mangaId;

  const VerticalReader({
    super.key,
    required this.chapter,
    required this.initialPage,
    required this.mangaId,
  });

  @override
  State<VerticalReader> createState() => _VerticalReaderState();
}

class _VerticalReaderState extends State<VerticalReader> {
  late ScrollController _scrollController;
  bool _hasSavedProgress = false;

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
    
    // Set initial scroll position if there's a saved page
    if (widget.initialPage > 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollController.jumpTo(widget.initialPage * 500.0); // Approximate page height
      });
    }
    
    // Listen to scroll to save progress
    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (!_hasSavedProgress && _scrollController.hasClients) {
      final scrollPosition = _scrollController.position.pixels;
      final pageIndex = (scrollPosition / 500).round();
      
      if (pageIndex > widget.initialPage) {
        final readingProvider = Provider.of<ReadingProvider>(context, listen: false);
        readingProvider.saveLastReadPage(widget.mangaId, pageIndex);
        _hasSavedProgress = true;
      }
    }
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    
    // Generate dummy pages (in real app, these would be actual images)
    final pageCount = widget.chapter.pageCount > 0 ? widget.chapter.pageCount : 30;
    
    return ListView.builder(
      controller: _scrollController,
      physics: const BouncingScrollPhysics(),
      itemCount: pageCount + 1, // +1 for end indicator
      itemBuilder: (context, index) {
        if (index == pageCount) {
          return _buildEndIndicator(context);
        }
        return _buildPage(context, index, themeProvider.isDarkMode);
      },
    );
  }

  Widget _buildPage(BuildContext context, int index, bool isDarkMode) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 2),
      color: isDarkMode ? Colors.grey.shade900 : Colors.grey.shade100,
      child: Column(
        children: [
          Container(
            height: 500,
            width: double.infinity,
            color: isDarkMode ? Colors.grey.shade800 : Colors.grey.shade200,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.image,
                    size: 48,
                    color: isDarkMode ? Colors.grey.shade600 : Colors.grey.shade400,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Page ${index + 1}',
                    style: TextStyle(
                      color: isDarkMode ? Colors.grey.shade400 : Colors.grey.shade600,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Chapter ${widget.chapter.chapterNumber}',
                    style: TextStyle(
                      fontSize: 12,
                      color: isDarkMode ? Colors.grey.shade500 : Colors.grey.shade500,
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (index == 0)
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'Chapter ${widget.chapter.chapterNumber}${widget.chapter.title.isNotEmpty ? ': ${widget.chapter.title}' : ''}',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: isDarkMode ? Colors.white : Colors.black,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildEndIndicator(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    
    return Container(
      height: 200,
      width: double.infinity,
      color: isDarkMode ? Colors.grey.shade900 : Colors.grey.shade100,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.check_circle, size: 48, color: Colors.green),
            const SizedBox(height: 16),
            Text(
              'End of Chapter ${widget.chapter.chapterNumber}',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: isDarkMode ? Colors.white70 : Colors.black54,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'You\'ve reached the end',
              style: TextStyle(
                fontSize: 14,
                color: isDarkMode ? Colors.grey.shade500 : Colors.grey.shade600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}