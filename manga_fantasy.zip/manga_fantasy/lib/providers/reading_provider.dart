import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/manga_model.dart';

class ReadingProvider extends ChangeNotifier {
  ReadingMode _currentReadingMode = ReadingMode.vertical;
  Map<String, String> _readingProgress = {}; // mangaId:chapterId
  Map<String, int> _lastReadPage = {}; // mangaId:pageIndex

  ReadingMode get currentReadingMode => _currentReadingMode;
  Map<String, String> get readingProgress => _readingProgress;
  Map<String, int> get lastReadPage => _lastReadPage;

  ReadingProvider() {
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    final modeString = prefs.getString('currentReadingMode');
    if (modeString != null) {
      _currentReadingMode = modeString == 'vertical'
          ? ReadingMode.vertical
          : ReadingMode.horizontal;
    }
    
    final progressJson = prefs.getString('readingProgress');
    if (progressJson != null) {
      // Parse JSON progress
    }
    
    notifyListeners();
  }

  Future<void> setReadingMode(ReadingMode mode) async {
    _currentReadingMode = mode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('currentReadingMode', 
        mode == ReadingMode.vertical ? 'vertical' : 'horizontal');
    notifyListeners();
  }

  Future<void> saveReadingProgress(String mangaId, String chapterId) async {
    _readingProgress[mangaId] = chapterId;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('readingProgress_$mangaId', chapterId);
    notifyListeners();
  }

  Future<void> saveLastReadPage(String mangaId, int pageIndex) async {
    _lastReadPage[mangaId] = pageIndex;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('lastReadPage_$mangaId', pageIndex);
    notifyListeners();
  }

  String? getLastReadChapter(String mangaId) {
    return _readingProgress[mangaId];
  }

  int? getLastReadPage(String mangaId) {
    return _lastReadPage[mangaId];
  }

  Future<void> toggleReadingMode() async {
    if (_currentReadingMode == ReadingMode.vertical) {
      await setReadingMode(ReadingMode.horizontal);
    } else {
      await setReadingMode(ReadingMode.vertical);
    }
  }
}