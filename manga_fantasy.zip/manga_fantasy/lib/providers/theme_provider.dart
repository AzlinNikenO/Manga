import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/manga_model.dart';

class ThemeProvider extends ChangeNotifier {
  bool _isDarkMode = false;
  double _fontSize = 14.0;
  ReadingMode _defaultReadingMode = ReadingMode.vertical;

  bool get isDarkMode => _isDarkMode;
  double get fontSize => _fontSize;
  ReadingMode get defaultReadingMode => _defaultReadingMode;

  ThemeProvider() {
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    _isDarkMode = prefs.getBool('isDarkMode') ?? false;
    _fontSize = prefs.getDouble('fontSize') ?? 14.0;
    final modeString = prefs.getString('defaultReadingMode');
    if (modeString != null) {
      _defaultReadingMode = modeString == 'vertical'
          ? ReadingMode.vertical
          : ReadingMode.horizontal;
    }
    notifyListeners();
  }

  Future<void> toggleTheme() async {
    _isDarkMode = !_isDarkMode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isDarkMode', _isDarkMode);
    notifyListeners();
  }

  Future<void> setFontSize(double size) async {
    _fontSize = size;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('fontSize', size);
    notifyListeners();
  }

  Future<void> setDefaultReadingMode(ReadingMode mode) async {
    _defaultReadingMode = mode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('defaultReadingMode', mode == ReadingMode.vertical ? 'vertical' : 'horizontal');
    notifyListeners();
  }

  ThemeData getLightTheme() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorScheme: ColorScheme.fromSeed(
        seedColor: Colors.indigo,
        brightness: Brightness.light,
      ),
      // HAPUS fontFamily
      textTheme: TextTheme(
        bodyLarge: TextStyle(fontSize: _fontSize),
        bodyMedium: TextStyle(fontSize: _fontSize),
        titleLarge: TextStyle(fontSize: _fontSize + 6, fontWeight: FontWeight.bold),
        titleMedium: TextStyle(fontSize: _fontSize + 4, fontWeight: FontWeight.w600),
        titleSmall: TextStyle(fontSize: _fontSize + 2, fontWeight: FontWeight.w500),
      ),
      scaffoldBackgroundColor: Colors.grey.shade50,
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
        centerTitle: true,
      ),
      cardTheme: const CardThemeData(
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(12)),
        ),
      ),
    );
  }

  ThemeData getDarkTheme() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(
        seedColor: Colors.indigo,
        brightness: Brightness.dark,
      ),
      // HAPUS fontFamily
      textTheme: TextTheme(
        bodyLarge: TextStyle(fontSize: _fontSize),
        bodyMedium: TextStyle(fontSize: _fontSize),
        titleLarge: TextStyle(fontSize: _fontSize + 6, fontWeight: FontWeight.bold),
        titleMedium: TextStyle(fontSize: _fontSize + 4, fontWeight: FontWeight.w600),
        titleSmall: TextStyle(fontSize: _fontSize + 2, fontWeight: FontWeight.w500),
      ),
      scaffoldBackgroundColor: Colors.grey.shade900,
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.grey[850],
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      cardTheme: const CardThemeData(
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(12)),
        ),
      ),
    );
  }
}