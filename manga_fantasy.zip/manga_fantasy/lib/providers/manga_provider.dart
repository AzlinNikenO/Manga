import 'package:flutter/material.dart';
import '../models/manga_model.dart';
import '../services/api_service.dart';
import '../services/websocket_service.dart';

class MangaProvider extends ChangeNotifier {
  List<Manga> _mangas = [];
  List<Manga> _fantasyMangas = [];
  bool _isLoading = false;
  String _errorMessage = '';  // PERBAIKAN: Gunakan String kosong sebagai default
  String _searchQuery = '';

  List<Manga> get mangas => _mangas;
  List<Manga> get fantasyMangas => _fantasyMangas;
  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;  // PERBAIKAN: Return String, bukan String?
  String get searchQuery => _searchQuery;

  MangaProvider() {
    loadMangas();
    _setupWebSocketListener();
  }

  void _setupWebSocketListener() {
    WebSocketService.addListener((data) {
      if (data['type'] == 'notification') {
        loadMangas();
      }
    });
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    _filterFantasyMangas();
    notifyListeners();
  }

  void setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  Future<void> loadMangas() async {
    setLoading(true);
    _errorMessage = '';
    
    try {
      final result = await ApiService.fetchMangas();
      
      // PERBAIKAN: Cek apakah result adalah List
      if (result is List) {
        _mangas = result.map((json) => Manga.fromJson(json)).toList();
        _filterFantasyMangas();
      } else {
        // Jika bukan List, coba ambil error message
        _errorMessage = result.toString();
      }
    } catch (e) {
      _errorMessage = e.toString();
      debugPrint('Error loading mangas: $e');
    } finally {
      setLoading(false);
    }
  }

  void _filterFantasyMangas() {
    if (_searchQuery.isEmpty) {
      _fantasyMangas = _mangas.where((manga) => 
        manga.genres.contains('Fantasy')
      ).toList();
    } else {
      _fantasyMangas = _mangas.where((manga) => 
        manga.genres.contains('Fantasy') &&
        manga.title.toLowerCase().contains(_searchQuery.toLowerCase())
      ).toList();
    }
    notifyListeners();
  }

  Future<bool> addManga(Manga manga) async {
    setLoading(true);
    _errorMessage = '';
    
    try {
      final result = await ApiService.createManga(manga.toJson());
      
      if (result['success'] == true) {
        await loadMangas();
        WebSocketService.sendNewMangaNotification(manga.title);
        setLoading(false);
        return true;
      } else {
        _errorMessage = result['error']?.toString() ?? 'Gagal menambah manga';
        setLoading(false);
        return false;
      }
    } catch (e) {
      _errorMessage = e.toString();
      setLoading(false);
      return false;
    }
  }

  Future<bool> updateManga(Manga manga) async {
    setLoading(true);
    _errorMessage = '';
    
    try {
      final result = await ApiService.updateManga(manga.toJson());
      
      if (result['success'] == true) {
        await loadMangas();
        setLoading(false);
        return true;
      } else {
        _errorMessage = result['error']?.toString() ?? 'Gagal update manga';
        setLoading(false);
        return false;
      }
    } catch (e) {
      _errorMessage = e.toString();
      setLoading(false);
      return false;
    }
  }

  Future<bool> deleteManga(int id) async {
    setLoading(true);
    _errorMessage = '';
    
    try {
      final result = await ApiService.deleteManga(id);
      
      if (result['success'] == true) {
        await loadMangas();
        setLoading(false);
        return true;
      } else {
        _errorMessage = result['error']?.toString() ?? 'Gagal hapus manga';
        setLoading(false);
        return false;
      }
    } catch (e) {
      _errorMessage = e.toString();
      setLoading(false);
      return false;
    }
  }

  Future<Manga?> searchMangaByTitle(String title) async {
    setLoading(true);
    _errorMessage = '';
    
    try {
      final result = await ApiService.searchManga(title);
      
      // Jika result adalah Map dan tidak ada error
      if (result is Map && result['error'] == null) {
        setLoading(false);
        return Manga.fromJson(result);
      } else {
        _errorMessage = result['error']?.toString() ?? 'Manga tidak ditemukan';
        setLoading(false);
        return null;
      }
    } catch (e) {
      _errorMessage = e.toString();
      setLoading(false);
      return null;
    }
  }

  Manga? getMangaById(int id) {
    try {
      return _mangas.firstWhere((m) => m.id == id);
    } catch (e) {
      return null;
    }
  }

  void clearError() {
    _errorMessage = '';
    notifyListeners();
  }
}