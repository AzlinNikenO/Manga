import 'dart:convert';
import 'package:http/http.dart' as http;
import '../utils/constants.dart';

class ApiService {
  static Future<dynamic> get(String endpoint) async {
    try {
      final url = Uri.parse('${Constants.baseUrl}$endpoint');
      final response = await http.get(url);
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      }
      return {'error': 'HTTP ${response.statusCode}'};
    } catch (e) {
      return {'error': e.toString()};
    }
  }

  static Future<Map<String, dynamic>> post(String endpoint, Map<String, dynamic> data) async {
    try {
      final url = Uri.parse('${Constants.baseUrl}$endpoint');
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(data),
      );
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      }
      return {'error': 'HTTP ${response.statusCode}'};
    } catch (e) {
      return {'error': e.toString()};
    }
  }

  // Manga CRUD Operations
  static Future<List<dynamic>> fetchMangas() async {
    final result = await get(Constants.apiRead);
    if (result is List) {
      return result;
    }
    return [];
  }

  static Future<Map<String, dynamic>> createManga(Map<String, dynamic> mangaData) async {
    return await post(Constants.apiCreate, mangaData);
  }

  static Future<Map<String, dynamic>> updateManga(Map<String, dynamic> mangaData) async {
    return await post(Constants.apiUpdate, mangaData);
  }

  static Future<Map<String, dynamic>> deleteManga(int id) async {
    return await post(Constants.apiDelete, {'id': id});
  }

  static Future<Map<String, dynamic>> searchManga(String title) async {
    return await get('${Constants.apiSearch}?title=${Uri.encodeComponent(title)}');
  }

  // Google Login
  static Future<Map<String, dynamic>> googleLogin(String idToken) async {
    return await post(Constants.apiGoogleLogin, {'id_token': idToken});
  }

  // FCM Token Registration
  static Future<Map<String, dynamic>> registerFcmToken(String userId, String token) async {
    return await post(Constants.apiRegisterToken, {
      'user_id': userId,
      'token': token,
    });
  }
}