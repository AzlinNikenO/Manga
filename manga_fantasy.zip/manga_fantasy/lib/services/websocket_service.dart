import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:flutter/foundation.dart';
import '../utils/constants.dart';

class WebSocketService {
  static WebSocketChannel? _channel;
  static final List<Function(Map<String, dynamic>)> _listeners = [];

  static void connect() {
    try {
      _channel = WebSocketChannel.connect(Uri.parse(Constants.wsUrl));
      _channel!.stream.listen((message) {
        final data = Map<String, dynamic>.from(message);
        for (var listener in _listeners) {
          listener(data);
        }
      }, onError: (error) {
        debugPrint('WebSocket error: $error');
      });
    } catch (e) {
      debugPrint('WebSocket connection error: $e');
    }
  }

  static void addListener(Function(Map<String, dynamic>) listener) {
    _listeners.add(listener);
  }

  static void removeListener(Function(Map<String, dynamic>) listener) {
    _listeners.remove(listener);
  }

  static void sendNewMangaNotification(String mangaTitle) {
    if (_channel != null) {
      _channel!.sink.add({
        'type': 'new_manga',
        'title': mangaTitle,
      });
    }
  }

  static void disconnect() {
    if (_channel != null) {
      _channel!.sink.close();
      _channel = null;
    }
  }
}