import 'package:flutter/foundation.dart';

class FcmService {
  static Future<void> initialize() async {
    debugPrint('FCM Service disabled for development');
  }
}