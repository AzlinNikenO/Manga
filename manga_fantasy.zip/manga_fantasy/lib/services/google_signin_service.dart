import 'package:flutter/material.dart';
import '../models/user.dart' as app;

class GoogleSignInService {
  // MOCK VERSION - Untuk development tanpa Google Sign-In
  static Future<app.User?> signInWithGoogle(BuildContext context) async {
    // Simulasi delay login
    await Future.delayed(const Duration(seconds: 1));
    
    // Return mock user
    return app.User(
      id: 'mock_user_001',
      email: 'test@example.com',
      name: 'Development User',
      picture: null,
    );
  }

  static Future<void> signOut() async {
    debugPrint('Mock: User signed out');
  }

  static bool isLoggedIn() {
    // Selalu return true untuk development
    return true;
  }

  static String? getCurrentUserId() {
    return 'mock_user_001';
  }

  static String? getCurrentUserEmail() {
    return 'test@example.com';
  }

  static String? getCurrentUserName() {
    return 'Development User';
  }
}