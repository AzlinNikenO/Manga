class Constants {
  // API Base URL - Ganti dengan IP komputer Anda (XAMPP)
  // Cek IP dengan 'ipconfig' di terminal
  static const String baseUrl = 'http://192.168.100.12/manga_api'; // GANTI DENGAN IP ANDA!
  
  // WebSocket URL (untuk notifikasi realtime)
  static const String wsUrl = 'ws://192.168.100.12:8080/ws';
  
  // API Endpoints
  static const String apiRead = '/api/manga/read.php';
  static const String apiCreate = '/api/manga/create.php';
  static const String apiUpdate = '/api/manga/update.php';
  static const String apiDelete = '/api/manga/delete.php';
  static const String apiReadOne = '/api/manga/read_one.php';
  static const String apiSearch = '/api/search.php';
  static const String apiGoogleLogin = '/auth/google_login.php';
  static const String apiRegisterToken = '/fcm/register_token.php';
  static const String apiSendNotification = '/fcm/send_notification.php';
  
  // SharedPreferences Keys
  static const String prefThemeMode = 'theme_mode';
  static const String prefFontSize = 'font_size';
  static const String prefReadingMode = 'reading_mode';
  static const String prefUser = 'user';
  static const String prefIsLoggedIn = 'is_logged_in';
  
  // Notification Channel
  static const String notificationChannelId = 'manga_notification_channel';
  static const String notificationChannelName = 'Notifikasi Manga';
  static const String notificationChannelDesc = 'Channel untuk notifikasi manga baru';
  
  // Reading Modes
  static const String readingModeVertical = 'vertical';
  static const String readingModeHorizontal = 'horizontal';
}