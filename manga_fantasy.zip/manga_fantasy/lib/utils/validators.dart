class Validators {
  static String? validateTitle(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Judul manga tidak boleh kosong';
    }
    if (value.length < 3) {
      return 'Judul minimal 3 karakter';
    }
    return null;
  }

  static String? validateAuthor(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Nama author tidak boleh kosong';
    }
    return null;
  }

  static String? validateSynopsis(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Sinopsis tidak boleh kosong';
    }
    if (value.length < 20) {
      return 'Sinopsis minimal 20 karakter';
    }
    return null;
  }

  static String? validateYear(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Tahun tidak boleh kosong';
    }
    final year = int.tryParse(value);
    if (year == null || year < 1900 || year > DateTime.now().year) {
      return 'Tahun tidak valid (1900-${DateTime.now().year})';
    }
    return null;
  }

  static String? validateRating(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Rating tidak boleh kosong';
    }
    final rating = double.tryParse(value);
    if (rating == null || rating < 0 || rating > 10) {
      return 'Rating harus antara 0-10';
    }
    return null;
  }
}