// Temporary disable - akan diperbaiki nanti
// import 'package:flutter/material.dart';
// import 'package:flutter_test/flutter_test.dart';
// import 'package:manga_fantasy/main.dart';

void main() {
  // Test temporarily disabled
}